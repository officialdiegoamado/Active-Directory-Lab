<#
    02-ou-structure.ps1

    Builds the OU tree under the domain root:

      corp.lab
      └─ Corp
         ├─ Admins                     <- privileged/admin accounts (Tier0/Tier1), kept OUT of Users on purpose
         ├─ Users
         │  ├─ IT / Sales / Finance / HR / Engineering
         ├─ Computers
         │  ├─ IT / Sales / Finance / HR / Engineering
         ├─ Groups
         │  ├─ IT / Sales / Finance / HR / Engineering
         └─ ServiceAccounts
            ├─ Shared                  <- cross-department service accounts
            └─ IT / Sales / Finance / HR / Engineering

    Why Admins is a separate top-level OU rather than living inside Users:
      - GPOs (drive maps, wallpaper, USB block, etc.) get linked to the
        department Users OUs. Admin accounts must NOT inherit those, since
        an admin account is only ever used for administrative logons, not
        for reading email or browsing the web where a desktop wallpaper
        policy or USB block would even matter.
      - It lets us apply a stricter, separate policy (tighter lockout /
        password settings, logon restrictions) to privileged accounts
        without touching the policy that applies to daily-driver users.
      - It keeps blast radius and auditing scope clear: anything under
        Admins is inherently higher-risk and should be reviewed/monitored
        differently than a Sales or HR user account.

    IDEMPOTENT: only creates an OU if it doesn't already exist; never
    touches an OU (or its contents) that's already there.
#>

#requires -RunAsAdministrator
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Import-Module (Join-Path $PSScriptRoot 'Lab.Common.psm1') -Force
Import-Module ActiveDirectory
Assert-RunningAsAdministrator
$cfg = Get-LabConfig

if (-not (Test-LabDomainControllerPromoted)) {
    throw 'This box is not a domain controller yet. Run 01-dc-promote.ps1 first.'
}

$domainDN = Get-LabDomainDN -DomainName $cfg.DomainName

# Corp
$corpOU = New-LabOU -Name $cfg.OU.Base -Path $domainDN
$corpDN = $corpOU.DistinguishedName

# Corp/Admins (flat - not split by department, see header comment)
New-LabOU -Name $cfg.OU.Admins -Path $corpDN | Out-Null

# Corp/Users, Corp/Computers, Corp/Groups - each split by department
foreach ($topLevel in @($cfg.OU.Users, $cfg.OU.Computers, $cfg.OU.Groups)) {
    $topOU = New-LabOU -Name $topLevel -Path $corpDN
    foreach ($dept in $cfg.OU.Departments) {
        New-LabOU -Name $dept -Path $topOU.DistinguishedName | Out-Null
    }
}

# Corp/ServiceAccounts - "Shared" plus one OU per department
$svcOU = New-LabOU -Name $cfg.OU.ServiceAccounts -Path $corpDN
New-LabOU -Name 'Shared' -Path $svcOU.DistinguishedName | Out-Null
foreach ($dept in $cfg.OU.Departments) {
    New-LabOU -Name $dept -Path $svcOU.DistinguishedName | Out-Null
}

Write-LabStep 'OU structure complete' -Level Done
Write-LabStep 'Phase 1 next step: run 03-seed-identity.ps1'
