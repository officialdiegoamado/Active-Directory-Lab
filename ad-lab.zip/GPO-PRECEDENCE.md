# GPO precedence in corp.lab

Everything here is produced by `04-gpos.ps1`. This document explains the
order Group Policy is applied in, and **which GPO wins on which object**.

## The GPOs

| # | GPO | Linked at | Enforced? | Security filtering | Side | What it does |
|---|-----|-----------|-----------|--------------------|------|--------------|
| 1 | **Default Domain Policy** | `corp.lab` (domain root) | no | Authenticated Users | Computer | Password length/age/history, account lockout. Set via `Set-ADDefaultDomainPasswordPolicy` — AD only honours account policy from a domain-root GPO. |
| 2 | **PSO-Admins-Strict** | *n/a — it's a PSO, not a GPO* | — | `SG-Tier1-Admins` + `Domain Admins` | account | 20-char min, 30-day max, lockout after 3. Overrides #1 for those members via precedence 10. |
| 3 | **CORP-Audit-Baseline** | `corp.lab` (domain root) | **YES** | Authenticated Users | Computer | Turns on logon + object-access + DS-access + account-management auditing. Enforced so no OU can switch it back off. |
| 4 | **CORP-User-Wallpaper** | `Corp/Users` | no | Authenticated Users | User | Locks the desktop wallpaper to `\\corp.lab\NETLOGON\corp-wallpaper.jpg`. |
| 5 | **CORP-Drive-Maps** | `Corp/Users` | no | Authenticated Users | User | `G:` → `\\FS01\Company$` for all; `S:` → `\\FS01\<Dept>$` via **item-level targeting** on `SG-<Dept>`. |
| 6 | **CORP-USB-Storage-Block** | `Corp/Users` | no | **Apply: `SG-AllStaff`; DENY-Apply: `SG-IT`** | User | `Deny_All` on removable storage. IT is exempt via the deny ACE. |
| 7 | **CORP-RDP-Restriction** | `Corp/Computers` | no | Authenticated Users | Computer | `SeRemoteInteractiveLogonRight` → Administrators + `SG-Tier1-Admins` only; Guests denied; NLA required. |

`Corp/Admins` has **no** user-side GPO linked to it or above it except items
at the domain root — that is the whole point of keeping admin accounts out of
`Corp/Users` (see `02-ou-structure.ps1` header).

## Order of application — "LSDOU"

Group Policy applies in this order, and **later overwrites earlier** on any
setting that conflicts:

1. **L**ocal group policy (on the machine itself)
2. **S**ite-linked GPOs
3. **D**omain-linked GPOs → *Default Domain Policy*, *CORP-Audit-Baseline*
4. **O**U-linked GPOs, from the **top of the tree down**:
   - `Corp` (nothing linked here directly)
   - `Corp/Users` → *CORP-User-Wallpaper*, *CORP-Drive-Maps*, *CORP-USB-Storage-Block*
   - `Corp/Users/<Dept>` (nothing linked — reserved for later)
   - `Corp/Computers` → *CORP-RDP-Restriction*
   - `Corp/Computers/<Dept>` (nothing linked)

So the **last writer wins**: a GPO on `Corp/Users/Sales` would beat one on
`Corp/Users`, which beats one at the domain root.

### Two tie-breakers that change the "last writer wins" rule

- **Link order.** When several GPOs are linked at the *same* container, the
  one with **link order 1 is processed last and wins**. GPMC shows this list;
  `Get-GPInheritance -Target <DN>` shows it in PowerShell.
- **Enforced (formerly "No Override").** An enforced link flips the rule: its
  settings win over anything applied later, *and* can't be blocked by "Block
  Inheritance". `CORP-Audit-Baseline` is enforced, so auditing is on
  everywhere regardless of OU-level GPOs or block-inheritance.

## Which GPO wins, per object

### A normal Sales user (`swilson`) logging on to `CLIENT01` (in `Corp/Computers/Sales`)

| Setting | Winning GPO | Why |
|---|---|---|
| Password / lockout rules | Default Domain Policy | Only domain-root account policy is honoured; no PSO applies to this user. |
| Auditing | CORP-Audit-Baseline | Enforced at domain root. |
| Wallpaper | CORP-User-Wallpaper | Linked at `Corp/Users`; user object is under it; no lower GPO overrides. |
| `S:` drive | CORP-Drive-Maps → **SG-Sales item only** | Item-level targeting: `swilson` is in `SG-Sales`, not the other four. `S:` = `\\FS01\Sales$`. |
| `G:` drive | CORP-Drive-Maps | Unfiltered item — everyone gets it. |
| USB storage | **Blocked** by CORP-USB-Storage-Block | `swilson` is in `SG-AllStaff` (via `SG-Sales`) and **not** in `SG-IT`, so the deny ACE doesn't hit her. |
| RDP logon right | CORP-RDP-Restriction (applies to the *computer*) | She can't RDP into `CLIENT01` unless she's also an admin or in `SG-Tier1-Admins`. |

### An IT user (`mmiller`, Help Desk) logging on to any client

Same as above **except USB storage is allowed** — `mmiller` is in `SG-IT`,
which has a DENY 'Apply group policy' ACE on `CORP-USB-Storage-Block`, and a
deny always beats the `SG-AllStaff` allow.

### An admin account (`adm-rwilliams`) logging on to `FS01`

| Setting | Winning policy | Why |
|---|---|---|
| Password / lockout | **PSO-Admins-Strict** | `adm-rwilliams` is in `SG-Tier1-Admins`; the PSO's precedence (10) beats the Default Domain Policy for this account. |
| Wallpaper / drive maps / USB block | **none apply** | The account lives in `Corp/Admins`; none of the `Corp/Users` GPOs reach it. |
| Auditing | CORP-Audit-Baseline | Enforced, domain-wide — machine policy, applies to `FS01`. |
| RDP logon right | CORP-RDP-Restriction | `FS01` is (once joined) under `Corp/Computers`; `SG-Tier1-Admins` is in the allowed list, so the RDP works. |

### A Sales *manager* (`blopez`)

Everything a Sales user gets, **plus** `blopez` is in `SG-Sales-Managers`
(nested inside `SG-Sales`). Nothing in Phase 2 grants extra policy to the
`-Managers` role groups yet — they exist so Phase 3's file-share ACLs and
Phase 4's scenarios can hang off them. The `S:` drive item still matches on
`SG-Sales` (managers are members through nesting).

## How to check it yourself

| Question | Command |
|---|---|
| Which GPOs apply to this user, and in what order? | `gpresult /r` (as the user) |
| Which apply to this computer? | `gpresult /r /scope computer` (elevated) |
| Full HTML report incl. denied GPOs and WMI/ILT filtering | `gpresult /h report.html` then open it |
| Link order + block-inheritance on an OU | `Get-GPInheritance -Target "OU=Users,OU=Corp,DC=corp,DC=lab"` |
| Everything one GPO contains | `Get-GPOReport -Name CORP-USB-Storage-Block -ReportType Html -Path usb.html` |
| Which password policy governs an account | `Get-ADUserResultantPasswordPolicy adm-rwilliams` |

## Deliberate "gotcha" wired in for Phase 4

`CORP-USB-Storage-Block` carries an explicit **DENY 'Apply group policy'** ACE
for `SG-IT`. Deny ACEs are invisible in the normal "Security Filtering" box in
GPMC (you have to open **Delegation → Advanced**), and `gpresult` reports the
GPO as *"Denied (Security)"* with no hint of *why*. That combination —
correct-looking allow list, a setting that mysteriously doesn't apply (or
mysteriously *does*, if someone adds a user to the wrong group) — is the basis
of the "deny ACE overriding an allow" break/fix scenario.
