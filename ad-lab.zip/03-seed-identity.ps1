<#
    03-seed-identity.ps1

    Seeds identity data on top of the OU structure from 02-ou-structure.ps1:
      - 60 users imported from data/users.csv (department, title, manager)
      - one department security group per department, plus a nested
        "-Managers" role group for each, all nested under a company-wide
        SG-AllStaff group
      - 3 shared service accounts
      - 5 privileged (admin) accounts, kept separate from daily-driver
        accounts and from each other by admin tier

    WHY PRIVILEGED ACCOUNTS ARE SEPARATE FROM DAILY-DRIVER ACCOUNTS:
    Real IT/sysadmin staff get TWO accounts: a normal one (e.g. jsmith) used
    for email, browsing, and daily work, and a separate admin one (e.g.
    adm-jsmith) used ONLY when performing administrative tasks. If the same
    account did both jobs, any phishing email, malware, or browser exploit
    that lands on that person's desktop would run with domain admin rights
    the moment they're logged in to check email. Splitting the accounts:
      - keeps standing privilege off the machines where users read email/
        browse the web (the highest-risk surface for credential theft)
      - lets Group Policy, password policy, and logon restrictions differ
        for admin accounts vs. daily-driver accounts (see 02's OU comment
        and the Phase 2 README)
      - makes privileged actions clearly attributable in logs to an
        intentional "I am doing admin work right now" action, instead of
        being indistinguishable from routine user activity
    This mirrors Microsoft's tiered administration model. Tier 0 here =
    Domain Admins (full forest/domain control). Tier 1 = server admins
    (elevated on member servers, not on the DC).

    IDEMPOTENT: re-running this script updates existing objects to match
    the CSV/group definitions below rather than erroring or duplicating.
#>

#requires -RunAsAdministrator
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Import-Module (Join-Path $PSScriptRoot 'Lab.Common.psm1') -Force
Import-Module ActiveDirectory
Assert-RunningAsAdministrator
$cfg = Get-LabConfig

if (-not (Test-LabDomainControllerPromoted)) {
    throw 'This box is not a domain controller yet. Run 01-dc-promote.ps1 first.'
}

$domainDN = Get-LabDomainDN -DomainName $cfg.DomainName
$corpDN = "OU=$($cfg.OU.Base),$domainDN"
$usersRootDN = "OU=$($cfg.OU.Users),$corpDN"
$groupsRootDN = "OU=$($cfg.OU.Groups),$corpDN"
$svcRootDN = "OU=$($cfg.OU.ServiceAccounts),$corpDN"
$adminsDN = "OU=$($cfg.OU.Admins),$corpDN"

if (-not (Get-ADOrganizationalUnit -Identity $corpDN -ErrorAction SilentlyContinue)) {
    throw 'OU structure not found. Run 02-ou-structure.ps1 first.'
}

$userPassword = ConvertTo-LabSecurePassword $cfg.DefaultUserPassword
$adminPassword = ConvertTo-LabSecurePassword $cfg.DefaultAdminPassword
$svcPassword = ConvertTo-LabSecurePassword $cfg.DefaultSvcPassword

function Set-LabADUser {
    param(
        [Parameter(Mandatory)][string]$SamAccountName,
        [Parameter(Mandatory)][string]$GivenName,
        [Parameter(Mandatory)][string]$Surname,
        [Parameter(Mandatory)][string]$Path,
        [string]$Title,
        [string]$Department,
        [Parameter(Mandatory)][System.Security.SecureString]$Password,
        [bool]$PasswordNeverExpires = $false,
        [string]$Description
    )
    $upn = "$SamAccountName@$($cfg.DomainName)"
    $displayName = "$GivenName $Surname"
    $existing = Get-ADUser -Filter "SamAccountName -eq '$SamAccountName'" -ErrorAction SilentlyContinue

    if ($existing) {
        Write-LabStep "User $SamAccountName already exists - updating attributes" -Level Skip
        Set-ADUser -Identity $existing.DistinguishedName `
            -GivenName $GivenName -Surname $Surname -DisplayName $displayName `
            -Title $Title -Department $Department -Description $Description `
            -Enabled $true -PasswordNeverExpires $PasswordNeverExpires
    }
    else {
        Write-LabStep "Creating user $SamAccountName ($displayName)"
        New-ADUser -Name $displayName -SamAccountName $SamAccountName -UserPrincipalName $upn `
            -GivenName $GivenName -Surname $Surname -DisplayName $displayName `
            -Title $Title -Department $Department -Description $Description `
            -Path $Path -AccountPassword $Password -Enabled $true `
            -PasswordNeverExpires $PasswordNeverExpires `
            -ChangePasswordAtLogon (-not $PasswordNeverExpires)
    }
}

function New-LabADGroup {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Path,
        [string]$Description,
        [ValidateSet('Global', 'DomainLocal', 'Universal')][string]$Scope = 'Global'
    )
    $existing = Get-ADGroup -Filter "Name -eq '$Name'" -ErrorAction SilentlyContinue
    if ($existing) {
        Write-LabStep "Group $Name already exists" -Level Skip
        return $existing
    }
    Write-LabStep "Creating group $Name"
    New-ADGroup -Name $Name -Path $Path -GroupScope $Scope -GroupCategory Security -Description $Description
    return Get-ADGroup -Filter "Name -eq '$Name'"
}

function Add-LabGroupMemberIfMissing {
    param(
        [Parameter(Mandatory)][string]$GroupIdentity,
        [Parameter(Mandatory)][string]$MemberIdentity
    )
    $current = Get-ADGroupMember -Identity $GroupIdentity -ErrorAction SilentlyContinue
    if ($current.SamAccountName -contains $MemberIdentity) {
        return
    }
    Add-ADGroupMember -Identity $GroupIdentity -Members $MemberIdentity
}

# -----------------------------------------------------------------
# 60 users from the CSV
# -----------------------------------------------------------------
Write-LabStep 'Seeding users from data/users.csv'
$users = Import-Csv (Join-Path $PSScriptRoot 'data\users.csv')

foreach ($u in $users) {
    $deptPath = "OU=$($u.Department),$usersRootDN"
    Set-LabADUser -SamAccountName $u.SamAccountName -GivenName $u.FirstName -Surname $u.LastName `
        -Path $deptPath -Title $u.Title -Department $u.Department -Password $userPassword `
        -Description "Seeded by 03-seed-identity.ps1"
}

Write-LabStep 'Setting manager attributes (second pass, managers must exist first)'
foreach ($u in $users) {
    if ([string]::IsNullOrWhiteSpace($u.ManagerSam)) { continue }
    $target = Get-ADUser -Identity $u.SamAccountName
    $manager = Get-ADUser -Identity $u.ManagerSam
    Set-ADUser -Identity $target.DistinguishedName -Manager $manager.DistinguishedName
}

# -----------------------------------------------------------------
# Department groups + nested manager role groups + company-wide group
# -----------------------------------------------------------------
Write-LabStep 'Creating department and role groups'
$allStaffGroup = New-LabADGroup -Name 'SG-AllStaff' -Path $groupsRootDN -Description 'Every employee (nested via department groups)'

foreach ($dept in $cfg.OU.Departments) {
    $deptGroupDN = "OU=$dept,$groupsRootDN"
    $deptGroup = New-LabADGroup -Name "SG-$dept" -Path $deptGroupDN -Description "All $dept department members"
    $mgrGroup = New-LabADGroup -Name "SG-$dept-Managers" -Path $deptGroupDN -Description "$dept managers/directors (nested into SG-$dept)"

    foreach ($u in $users | Where-Object Department -eq $dept) {
        Add-LabGroupMemberIfMissing -GroupIdentity $deptGroup.SamAccountName -MemberIdentity $u.SamAccountName
        if ($u.Title -match 'Director|Manager') {
            Add-LabGroupMemberIfMissing -GroupIdentity $mgrGroup.SamAccountName -MemberIdentity $u.SamAccountName
        }
    }

    # Nest the role group into the department group, and the department
    # group into the company-wide group - a 3-level nesting chain that
    # Phase 3's file share permissions and Phase 4's break/fix scenarios
    # will build on.
    Add-LabGroupMemberIfMissing -GroupIdentity $deptGroup.SamAccountName -MemberIdentity $mgrGroup.SamAccountName
    Add-LabGroupMemberIfMissing -GroupIdentity $allStaffGroup.SamAccountName -MemberIdentity $deptGroup.SamAccountName
}

# -----------------------------------------------------------------
# Service accounts (3) - shared, non-departmental
# -----------------------------------------------------------------
Write-LabStep 'Creating service accounts'
$serviceAccounts = @(
    @{ Sam = 'svc-sql';    Name = 'SQL Server Service';    Desc = 'Service account for the lab SQL Server instance' }
    @{ Sam = 'svc-backup'; Name = 'Backup Service';        Desc = 'Service account for the backup job on FS01' }
    @{ Sam = 'svc-webapp'; Name = 'Internal Web App Pool'; Desc = 'App pool identity for the internal web app' }
)
foreach ($svc in $serviceAccounts) {
    Set-LabADUser -SamAccountName $svc.Sam -GivenName $svc.Name -Surname 'Service Account' `
        -Path "OU=Shared,$svcRootDN" -Title 'Service Account' -Department 'ServiceAccounts' `
        -Password $svcPassword -PasswordNeverExpires $true -Description $svc.Desc
}

# -----------------------------------------------------------------
# Privileged accounts (5) - separate OU, separate from daily-driver
# accounts. Tier 0 = Domain Admins, Tier 1 = server admins (Phase 3).
# -----------------------------------------------------------------
Write-LabStep 'Creating privileged (admin) accounts'
$tier1Group = New-LabADGroup -Name 'SG-Tier1-Admins' -Path $adminsDN -Description 'Elevated on member servers only, not on the DC' -Scope DomainLocal

$privilegedAccounts = @(
    @{ Sam = 'adm-jsmith';    Given = 'James';   Sur = 'Smith';     Tier = 0; Desc = 'Tier 0 admin account for jsmith (IT Director)' }
    @{ Sam = 'adm-mjohnson';  Given = 'Mary';     Sur = 'Johnson';   Tier = 0; Desc = 'Tier 0 admin account for mjohnson (Systems Administrator)' }
    @{ Sam = 'adm-rwilliams'; Given = 'Robert';   Sur = 'Williams';  Tier = 1; Desc = 'Tier 1 admin account for rwilliams (Systems Administrator)' }
    @{ Sam = 'adm-pbrown';    Given = 'Patricia'; Sur = 'Brown';     Tier = 1; Desc = 'Tier 1 admin account for pbrown (Systems Administrator)' }
    @{ Sam = 'adm-jjones';    Given = 'John';     Sur = 'Jones';     Tier = 1; Desc = 'Tier 1 admin account for jjones (Network Administrator)' }
)

foreach ($adm in $privilegedAccounts) {
    Set-LabADUser -SamAccountName $adm.Sam -GivenName $adm.Given -Surname $adm.Sur `
        -Path $adminsDN -Title "Tier $($adm.Tier) Administrator" -Department 'IT' `
        -Password $adminPassword -Description $adm.Desc

    if ($adm.Tier -eq 0) {
        Add-LabGroupMemberIfMissing -GroupIdentity 'Domain Admins' -MemberIdentity $adm.Sam
    }
    else {
        Add-LabGroupMemberIfMissing -GroupIdentity $tier1Group.SamAccountName -MemberIdentity $adm.Sam
    }
}

Write-LabStep 'Identity seeding complete' -Level Done
Write-LabStep "60 users, 5 department groups (+5 manager role groups), 3 service accounts, 5 privileged accounts"
Write-LabStep 'Phase 1 complete. Stop here and verify before starting Phase 2 (Group Policy).'
