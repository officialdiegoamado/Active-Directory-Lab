@{
    # ---------------------------------------------------------------
    # Central configuration for the corp.lab Active Directory home lab.
    # Every script dot-sources Lab.Common.psm1 and calls Get-LabConfig
    # to read this file, so change values here rather than in scripts.
    # ---------------------------------------------------------------

    DomainName     = 'corp.lab'
    NetBIOSName    = 'CORP'
    DCName         = 'DC01'
    FileServerName = 'FS01'
    Client1Name    = 'CLIENT01'
    Client2Name    = 'CLIENT02'

    # Lab-only default passwords. Meets Windows complexity requirements.
    # Change these before you run 01/03 if you want different values -
    # they are stored in plaintext here because this is a disposable lab,
    # never do this in a real environment.
    # Lengths chosen to also satisfy the Phase 2 policy (14-char domain min,
    # 20-char for admin accounts) so seeding still works after 04-gpos.ps1.
    DefaultUserPassword  = 'ChangeMeUser-2026!'
    DefaultAdminPassword = 'ChangeMeAdmin-Account-2026!'
    DefaultSvcPassword   = 'ChangeMeService-2026!'

    Network = @{
        InterfaceAlias      = $null              # $null = auto-detect the first "Up" physical adapter
        PrefixLength        = 24
        Gateway             = '192.168.50.1'
        DCIPAddress         = '192.168.50.10'
        FSIPAddress         = '192.168.50.11'
        DNSForwarders       = @('1.1.1.1', '8.8.8.8')
        ReverseZoneNetworkID = '192.168.50.0/24'
    }

    DHCP = @{
        ScopeName     = 'CORP-LAN'
        ScopeID       = '192.168.50.0'
        SubnetMask    = '255.255.255.0'
        StartRange    = '192.168.50.100'
        EndRange      = '192.168.50.200'
        LeaseDuration = '08:00:00'   # parsed with [TimeSpan]::Parse() by the consuming script
        Router        = '192.168.50.1'
    }

    OU = @{
        Base            = 'Corp'
        Admins          = 'Admins'
        Users           = 'Users'
        Computers       = 'Computers'
        Groups          = 'Groups'
        ServiceAccounts = 'ServiceAccounts'
        Departments     = @('IT', 'Sales', 'Finance', 'HR', 'Engineering')
    }

    # ---------------------------------------------------------------
    # Phase 2 - Group Policy (04-gpos.ps1)
    # ---------------------------------------------------------------
    GPO = @{
        # Domain-wide password + lockout policy. Applied to the Default
        # Domain Policy via Set-ADDefaultDomainPasswordPolicy, because AD
        # only honours password/lockout settings that come from a GPO
        # linked at the *domain root* - see 04-gpos.ps1 header.
        Password = @{
            MinLength          = 14
            MaxAgeDays         = 90
            MinAgeDays         = 1
            HistoryCount       = 24
            ComplexityEnabled  = $true
            ReversibleEncryption = $false
            LockoutThreshold   = 5     # bad attempts before lockout
            LockoutDurationMin = 15    # minutes locked
            LockoutWindowMin   = 15    # minutes the bad-attempt counter is measured over
        }

        # Stricter fine-grained password policy (PSO) for the privileged
        # accounts in Corp/Admins - demonstrates that admin accounts get
        # their own rules without touching everyone else's.
        AdminPassword = @{
            Name             = 'PSO-Admins-Strict'
            Precedence       = 10
            MinLength        = 20
            MaxAgeDays       = 30
            HistoryCount     = 24
            LockoutThreshold = 3
            LockoutDurationMin = 30
            LockoutWindowMin   = 30
            AppliesToGroup   = 'SG-Tier1-Admins'   # plus Domain Admins, added by the script
        }

        # Drive mapping (GPP Drives + item-level targeting by dept group)
        FileServerHost = 'FS01'
        CommonDrive    = @{ Letter = 'G'; Share = 'Company$';  Label = 'Company (G:)' }
        DeptDriveLetter = 'S'                                   # \\FS01\<Dept>$  ->  S:

        # Desktop wallpaper (UNC path readable by all users - NETLOGON is)
        WallpaperUNC   = '\\corp.lab\NETLOGON\corp-wallpaper.jpg'
        WallpaperStyle = '2'                                    # 0 center, 2 stretch, 6 fit, 10 fill

        # USB storage block: applies to everyone EXCEPT this group (deny ACE)
        UsbBlockExemptGroup = 'SG-IT'

        # RDP: only these may log on over Remote Desktop (SeRemoteInteractiveLogonRight)
        RdpAllowedGroup = 'SG-Tier1-Admins'                     # plus BUILTIN\Administrators

        # Where 04-gpos.ps1 writes/reads GPO backups (relative to the repo)
        BackupFolder = 'gpos'
    }
}
