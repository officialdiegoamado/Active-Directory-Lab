# corp.lab — Active Directory home lab

A from-scratch AD environment: 1 domain controller, 1 member file server, 2
Windows 11 clients. You install/boot the VMs manually; everything after
first boot is a numbered, idempotent PowerShell script in this repo.

Built in phases, one PR of scripts at a time. **This README grows with each
phase** — it now covers Phases 1 and 2.

## Lab topology

| Host | Role | OS | IP | Notes |
|---|---|---|---|---|
| DC01 | Domain Controller, DNS, DHCP | Windows Server 2022 | 192.168.50.10 (static) | forest root: `corp.lab` |
| FS01 | Member server, file server | Windows Server 2022 | 192.168.50.11 (static) | joins domain in Phase 3 |
| CLIENT01 | Workstation | Windows 11 | DHCP (192.168.50.100–200) | joins domain manually |
| CLIENT02 | Workstation | Windows 11 | DHCP (192.168.50.100–200) | joins domain manually |

**Put all 4 VMs on an isolated virtual switch** (Hyper-V "Internal"/"Private"
or a VMware/VirtualBox host-only network), not bridged to your home LAN.
DC01 is the only DHCP server in this network — if it's bridged to your home
router, you'll get two DHCP servers fighting over the same subnet.

- Subnet: `192.168.50.0/24`, gateway `192.168.50.1` (not required in an
  isolated network unless you also NAT it out — leave the VMs unable to
  reach the internet, or set up NAT on the host, either is fine for the lab)
- DNS: DC01 (192.168.50.10) is authoritative for `corp.lab` and forwards
  everything else to `1.1.1.1` / `8.8.8.8`
- DHCP scope `CORP-LAN`: 192.168.50.100–200, hands out DC01 as DNS server

All of the above lives in one place: **`Lab.Config.psd1`**. Change values
there before running scripts if you want a different domain name, subnet,
etc. — don't hand-edit the numbered scripts.

## Build order

Run each script **on the target VM**, in an elevated PowerShell session,
after that VM's OS is installed and it has network connectivity.

1. **DC01**: `01-dc-promote.ps1` — static IP, rename to DC01, install AD DS/DNS/DHCP,
   promote new forest `corp.lab`, configure forwarders + reverse zone + DHCP scope.
   This script reboots the VM twice (rename, then promotion) — **just re-run it
   after each reboot**, it detects what's already done and continues.
2. **DC01**: `02-ou-structure.ps1` — builds the OU tree (see below).
3. **DC01**: `03-seed-identity.ps1` — creates 60 users, department/role groups,
   3 service accounts, 5 privileged accounts.
4. **DC01**: `04-gpos.ps1` — Phase 2. Creates + links every lab GPO from code,
   backs each up into `gpos/`. Re-runnable. See **Phase 2** below.

Phases 3–5 (file server, break/fix scenarios, health checks) will add scripts
`05-*` / `06-*`, a `scenarios/` folder, and more rows to the tables below as
they land.

## Phase 2 — Group Policy

`04-gpos.ps1` builds seven policies **as code** — nothing is clicked in GPMC —
and drops a backup of each into `gpos/` so the definitions live in the repo.

| GPO | Linked at | Purpose |
|---|---|---|
| Default Domain Policy | domain root | 14-char passwords, lockout 5 tries / 15 min (`Set-ADDefaultDomainPasswordPolicy`) |
| PSO-Admins-Strict | *(PSO)* `SG-Tier1-Admins` + `Domain Admins` | 20-char passwords, lockout after 3 — admin accounts only |
| CORP-Audit-Baseline | domain root, **Enforced** | logon + object-access + DS-access auditing |
| CORP-User-Wallpaper | `Corp/Users` | locked corporate wallpaper from NETLOGON |
| CORP-Drive-Maps | `Corp/Users` | `G:` for all, `S:` per department via **item-level targeting** |
| CORP-USB-Storage-Block | `Corp/Users` | blocks USB storage; **security filtering** + a DENY ACE exempts `SG-IT` |
| CORP-RDP-Restriction | `Corp/Computers` | only Administrators + `SG-Tier1-Admins` may log on via RDP; NLA required |

Run it, then:

```powershell
.\04-gpos.ps1                # build from code + refresh gpos\ backups
.\04-gpos.ps1 -FromBackup    # rebuild the GPOs by importing gpos\ instead
```

**Read [`GPO-PRECEDENCE.md`](GPO-PRECEDENCE.md)** for the LSDOU order, how
Enforced and link order change it, and a per-object table of which GPO wins
for a normal user, an IT user, an admin account, and a manager.

Notes:
- The `S:` / `G:` drive maps and the department shares they point at don't
  exist until Phase 3 (`05-fileserver.ps1`) creates them on FS01.
- `04-gpos.ps1` edits SYSVOL directly for the security-template and drive-map
  GPOs (writing `GptTmpl.inf` / `Drives.xml`, registering the client-side
  extension, bumping the GPO version). It only does this when content actually
  changes, so re-runs don't inflate version numbers.
- The DENY 'Apply group policy' ACE on `CORP-USB-Storage-Block` is deliberate —
  it's the seed for a Phase 4 break/fix scenario.

## OU structure

```
corp.lab
└─ Corp
   ├─ Admins                     (privileged accounts only — see below)
   ├─ Users
   │  ├─ IT
   │  ├─ Sales
   │  ├─ Finance
   │  ├─ HR
   │  └─ Engineering
   ├─ Computers
   │  ├─ IT / Sales / Finance / HR / Engineering
   ├─ Groups
   │  ├─ IT / Sales / Finance / HR / Engineering
   └─ ServiceAccounts
      ├─ Shared                  (svc-sql, svc-backup, svc-webapp)
      └─ IT / Sales / Finance / HR / Engineering  (empty, reserved)
```

`Corp/Computers/<Dept>` OUs are provisioned now but empty — when you join
FS01/CLIENT01/CLIENT02 to the domain, move their computer objects into the
right department OU manually (`Get-ADComputer` + `Move-ADObject`, or drag
in ADUC). Domain-joined computers land in the default `Computers` container
first; nothing in this repo redirects that automatically.

### Why `Corp/Admins` is separate from `Corp/Users`

Privileged (`adm-*`) accounts live in their own OU, not mixed in with
regular department users, so that:
- Group Policy aimed at daily-driver users (drive maps, wallpaper, USB
  block, etc. — Phase 2) never applies to an admin account
- Admin accounts can get their own, stricter password/lockout policy later
  without touching the policy for everyone else
- Anything under `Corp/Admins` is unambiguously "privileged" for auditing

## Identity model

- **60 users** in `data/users.csv` — real department/title/manager
  hierarchy (Director → Manager → IC) across IT, Sales, Finance, HR, and
  Engineering. Re-running `03-seed-identity.ps1` updates existing users
  from the CSV rather than duplicating them.
- **Groups**: one global security group per department (`SG-IT`,
  `SG-Sales`, …), each with a nested `SG-<Dept>-Managers` role group
  containing that department's directors/managers, all nested into a
  company-wide `SG-AllStaff`. This 3-level nesting chain is deliberate —
  Phase 3's file-share ACLs and Phase 4's break/fix scenarios build on it.
- **3 service accounts** (`svc-sql`, `svc-backup`, `svc-webapp`) in
  `Corp/ServiceAccounts/Shared`, password-never-expires, not used
  interactively.
- **5 privileged accounts**, separate from daily-driver accounts:
  - Tier 0 (Domain Admins): `adm-jsmith`, `adm-mjohnson`
  - Tier 1 (`SG-Tier1-Admins`, elevated on member servers only): `adm-rwilliams`,
    `adm-pbrown`, `adm-jjones`
  - See the comment header in `03-seed-identity.ps1` for the full
    rationale on why admin accounts are split from the accounts the same
    people use day-to-day.

## Credentials (lab only — never do this in production)

Default passwords are stored in plaintext in `Lab.Config.psd1` because this
is a disposable, isolated lab. Change them there before seeding if you
want different values.

| Account type | Example | Password | Notes |
|---|---|---|---|
| Daily-driver user | `jsmith` | `DefaultUserPassword` in config | must change at first logon |
| Service account | `svc-sql` | `DefaultSvcPassword` in config | never expires, not for interactive logon |
| Privileged (admin) | `adm-jsmith` | `DefaultAdminPassword` in config | use only for admin tasks, never daily work |
| DSRM (DC01) | — | set interactively during `01-dc-promote.ps1` | not stored anywhere |

The default passwords in `Lab.Config.psd1` are sized to satisfy the Phase 2
policy (14-char domain min, 20-char for admin accounts) so `03-seed-identity.ps1`
still works after `04-gpos.ps1` has run. If you shorten them, seeding new
accounts will fail against the policy. Users are forced to change at first logon
regardless.

## Troubleshooting workflow

Full workflow lands with Phase 5 (`06-healthcheck.ps1`). For Phase 1, if a
script fails partway through:
1. Re-run the same script — every script here checks current state first
   and skips whatever's already done.
2. If `01-dc-promote.ps1` fails after a reboot, confirm the computer name
   and IP actually changed (`hostname`, `ipconfig`) before re-running.
3. `02`/`03` both refuse to run until `Test-LabDomainControllerPromoted`
   is true (i.e., the `NTDS` service exists) — if you see that error, go
   finish `01-dc-promote.ps1` first.
