<#
    04-gpos.ps1  -  PHASE 2: Group Policy, built as code

    Creates and links every lab GPO from script, backs each one up into
    .\gpos\ so the definitions are version-controlled, and (with -FromBackup)
    rebuilds the whole set by IMPORTING those backups instead of clicking
    through GPMC. Nothing in this phase is configured by hand in the editor.

    GPOs produced
    -------------
      1. Default Domain Policy         password + lockout policy (domain root)
      2. PSO-Admins-Strict             stricter password rules for admin accounts
      3. CORP-Audit-Baseline           logon + object-access auditing (domain root, Enforced)
      4. CORP-User-Wallpaper           locked desktop wallpaper           (Corp/Users)
      5. CORP-Drive-Maps               S:/G: drives, item-level targeting (Corp/Users)
      6. CORP-USB-Storage-Block        blocks USB mass storage, non-IT    (Corp/Users)
      7. CORP-RDP-Restriction          restricts who may log on via RDP   (Corp/Computers)

    WHY PASSWORD POLICY IS NOT A CUSTOM GPO
    Active Directory only reads account policy (password length/age/history,
    lockout) from a GPO linked at the DOMAIN ROOT. A password GPO linked to an
    OU changes the *local* SAM policy of machines in that OU, not domain
    accounts. The supported place for domain password policy is the Default
    Domain Policy, so this script writes there via Set-ADDefaultDomainPasswordPolicy
    (still "as code"). Per-group exceptions use a fine-grained password policy
    object (PSO), which is how you give admin accounts tougher rules - see
    PSO-Admins-Strict below.

    SECURITY FILTERING + ITEM-LEVEL TARGETING (required by the brief)
      - CORP-USB-Storage-Block uses SECURITY FILTERING: 'Authenticated Users'
        keeps Read (needed for the GPO to process at all on 2016+), Apply is
        granted to SG-AllStaff, and a DENY 'Apply group policy' ACE is added
        for SG-IT. A deny always wins, so IT is carved out. That deny ACE is
        also the seed for a Phase 4 break/fix scenario.
      - CORP-Drive-Maps uses ITEM-LEVEL TARGETING inside Group Policy
        Preferences: one Drives.xml with a mapping per department, each item
        filtered to CORP\SG-<Dept>. A Sales user evaluates every item, but
        only the SG-Sales one applies.

    PRECEDENCE
    Full write-up (LSDOU, link order, Enforced, block inheritance, and which
    GPO wins on which object) is in GPO-PRECEDENCE.md.

    IDEMPOTENT / RE-RUNNABLE
      - GPOs are created only if missing (Get-GPO first).
      - Registry values are set every run (Set-GPRegistryValue overwrites - cheap, safe).
      - SYSVOL files (security templates, Drives.xml) are only rewritten when
        their content actually changes, and the GPO version + client-side
        extension list are only bumped on a real change - so re-running does
        not inflate version numbers or trigger pointless client re-processing.
      - Links are ensured (created if missing, otherwise state re-asserted).

    USAGE
      .\04-gpos.ps1                # build from code, then back up to .\gpos\
      .\04-gpos.ps1 -FromBackup    # wipe + reimport the GPOs from .\gpos\
      .\04-gpos.ps1 -SkipBackup    # build from code, don't refresh the backups
#>

#requires -RunAsAdministrator
[CmdletBinding()]
param(
    [switch]$FromBackup,
    [switch]$SkipBackup
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Import-Module (Join-Path $PSScriptRoot 'Lab.Common.psm1') -Force
Import-Module ActiveDirectory
Import-Module GroupPolicy
Assert-RunningAsAdministrator
$cfg = Get-LabConfig

if (-not (Test-LabDomainControllerPromoted)) {
    throw 'This box is not a domain controller yet. Run 01-dc-promote.ps1 first.'
}

$domainDN      = Get-LabDomainDN -DomainName $cfg.DomainName
$domainFqdn    = $cfg.DomainName
$corpDN        = "OU=$($cfg.OU.Base),$domainDN"
$usersRootDN   = "OU=$($cfg.OU.Users),$corpDN"
$computersRootDN = "OU=$($cfg.OU.Computers),$corpDN"
$adminsDN      = "OU=$($cfg.OU.Admins),$corpDN"
$g             = $cfg.GPO

if (-not (Get-ADOrganizationalUnit -Identity $corpDN -ErrorAction SilentlyContinue)) {
    throw 'OU structure not found. Run 02-ou-structure.ps1, then 03-seed-identity.ps1, first.'
}
if (-not (Get-ADGroup -Filter "Name -eq 'SG-AllStaff'" -ErrorAction SilentlyContinue)) {
    throw 'SG-AllStaff not found. Run 03-seed-identity.ps1 first.'
}

$backupRoot = Join-Path $PSScriptRoot $g.BackupFolder
New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null

# Well-known client-side-extension identifiers. Each of our GPOs uses exactly
# one CSE, so the gPC*ExtensionNames value is just "[{CSE}{TOOL}]" - no merge
# logic needed. (GPMC would write these for you; we do it because we edit
# SYSVOL directly.)
$CSE_SECURITY   = '[{827D319E-6EAC-11D2-A4EA-00C04F79F83A}{803E14A0-B4FB-11D0-A0D0-00A0C90F574B}]'
$CSE_DRIVEMAPS  = '[{00000000-0000-0000-0000-000000000000}{2EA1A81B-48E5-45E9-8BB7-A6E3AC170006}][{5794DAFD-BE60-433F-88A2-1A31939AC01F}{2EA1A81B-48E5-45E9-8BB7-A6E3AC170006}]'

# Fixed GUIDs per drive item so regenerated Drives.xml is byte-identical
# across runs (keeps the "only rewrite on real change" check honest).
$DRIVE_UID = @{
    Common      = '{6B1A4E10-0001-4C7A-9E10-000000000001}'
    IT          = '{6B1A4E10-0002-4C7A-9E10-000000000002}'
    Sales       = '{6B1A4E10-0003-4C7A-9E10-000000000003}'
    Finance     = '{6B1A4E10-0004-4C7A-9E10-000000000004}'
    HR          = '{6B1A4E10-0005-4C7A-9E10-000000000005}'
    Engineering = '{6B1A4E10-0006-4C7A-9E10-000000000006}'
}

# =====================================================================
# Helpers
# =====================================================================

function Get-LabGpo {
    param([Parameter(Mandatory)][string]$Name, [string]$Comment = 'Managed by 04-gpos.ps1 - do not edit in GPMC')
    $gpo = Get-GPO -Name $Name -ErrorAction SilentlyContinue
    if ($gpo) {
        Write-LabStep "GPO '$Name' already exists" -Level Skip
        return $gpo
    }
    Write-LabStep "Creating GPO '$Name'"
    New-GPO -Name $Name -Comment $Comment
}

function Set-LabGpoLink {
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Target,
        [ValidateSet('Yes', 'No')][string]$Enforced = 'No'
    )
    $existing = (Get-GPInheritance -Target $Target).GpoLinks | Where-Object { $_.DisplayName -eq $Name }
    if ($existing) {
        Set-GPLink -Name $Name -Target $Target -LinkEnabled Yes -Enforced $Enforced | Out-Null
        Write-LabStep "Link '$Name' -> $Target present (Enforced=$Enforced)" -Level Skip
    }
    else {
        New-GPLink -Name $Name -Target $Target -LinkEnabled Yes -Enforced $Enforced | Out-Null
        Write-LabStep "Linked '$Name' -> $Target (Enforced=$Enforced)" -Level Done
    }
}

function Set-LabGpoApplyGroups {
    <#
        Security filtering. 'Authenticated Users' is dropped to Read-only
        (it MUST keep Read or the GPO won't process on Server 2016+ /
        the June 2016 MS16-072 change); Apply is granted to $Groups.
    #>
    param([Parameter(Mandatory)][string]$Name, [Parameter(Mandatory)][string[]]$Groups)
    Set-GPPermission -Name $Name -TargetName 'Authenticated Users' -TargetType Group `
        -PermissionLevel GpoRead -Replace -Confirm:$false | Out-Null
    foreach ($grp in $Groups) {
        Set-GPPermission -Name $Name -TargetName $grp -TargetType Group `
            -PermissionLevel GpoApply -Replace -Confirm:$false | Out-Null
    }
    Write-LabStep "Security filtering on '$Name' -> Apply: $($Groups -join ', ')" -Level Done
}

function Add-LabGpoDenyApply {
    <#
        Adds a DENY 'Apply group policy' ACE for a group on the GPO's AD
        object. The GroupPolicy cmdlets can't express a deny, so we edit
        the security descriptor directly. Deny beats allow, so members of
        $GroupName never get the policy even though SG-AllStaff does.
    #>
    param([Parameter(Mandatory)][guid]$GpoId, [Parameter(Mandatory)][string]$GroupName)
    $applyGpRight = [guid]'edacfd8f-ffb3-11d1-b41d-00a0c968f939'   # "Apply Group Policy" extended right
    $grp = Get-ADGroup -Identity $GroupName
    $path = "AD:\CN={$GpoId},CN=Policies,CN=System,$domainDN"
    $acl = Get-Acl -Path $path
    $already = $acl.Access | Where-Object {
        $_.AccessControlType -eq 'Deny' -and $_.ObjectType -eq $applyGpRight -and
        $_.IdentityReference.Translate([System.Security.Principal.SecurityIdentifier]) -eq $grp.SID
    }
    if ($already) {
        Write-LabStep "Deny 'Apply group policy' for $GroupName already on GPO" -Level Skip
        return
    }
    $ace = New-Object System.DirectoryServices.ActiveDirectoryAccessRule(
        $grp.SID, 'ExtendedRight', 'Deny', $applyGpRight, 'None')
    $acl.AddAccessRule($ace)
    Set-Acl -Path $path -AclObject $acl
    Write-LabStep "Added DENY 'Apply group policy' for $GroupName" -Level Done
}

function Write-LabSysvolFile {
    <# Write only if content changed. Returns $true when it wrote. #>
    param(
        [Parameter(Mandatory)][string]$Path,
        [Parameter(Mandatory)][string]$Content,
        [Parameter(Mandatory)][System.Text.Encoding]$Encoding
    )
    $dir = Split-Path -Parent $Path
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    $normNew = ($Content -replace "`r", '').TrimEnd()
    if (Test-Path $Path) {
        $normOld = ([IO.File]::ReadAllText($Path) -replace "`r", '').TrimEnd()
        if ($normOld -eq $normNew) { return $false }
    }
    [IO.File]::WriteAllText($Path, $Content, $Encoding)
    return $true
}

function Add-LabGpoExtension {
    param([Parameter(Mandatory)][guid]$GpoId, [ValidateSet('Machine', 'User')][string]$Side, [Parameter(Mandatory)][string]$ExtString)
    $dn = "CN={$GpoId},CN=Policies,CN=System,$domainDN"
    $attr = if ($Side -eq 'Machine') { 'gPCMachineExtensionNames' } else { 'gPCUserExtensionNames' }
    $obj = Get-ADObject -Identity $dn -Properties $attr
    $cur = [string]$obj.$attr
    if ($cur -and $cur.ToUpper() -eq $ExtString.ToUpper()) { return }
    Set-ADObject -Identity $dn -Replace @{ $attr = $ExtString }
    Write-LabStep "Registered $Side client-side extension on GPO" -Level Done
}

function Step-LabGpoVersion {
    <# Increment the user or computer half of the GPO version, in AD and gpt.ini. #>
    param([Parameter(Mandatory)][guid]$GpoId, [ValidateSet('Machine', 'User')][string]$Side)
    $dn = "CN={$GpoId},CN=Policies,CN=System,$domainDN"
    $obj = Get-ADObject -Identity $dn -Properties versionNumber
    $v = [int64]$obj.versionNumber
    $user = $v -band 0xFFFF
    $comp = ($v -shr 16) -band 0xFFFF
    if ($Side -eq 'Machine') { $comp++ } else { $user++ }
    $new = (($comp -band 0xFFFF) * 65536) + ($user -band 0xFFFF)
    Set-ADObject -Identity $dn -Replace @{ versionNumber = [int]$new }
    $gptIni = "\\$domainFqdn\SYSVOL\$domainFqdn\Policies\{$GpoId}\gpt.ini"
    Set-Content -Path $gptIni -Value "[General]`r`nVersion=$new" -Encoding Ascii
    Write-LabStep "Bumped $Side GPO version -> $new" -Level Done
}

function Set-LabGpoSecurityTemplate {
    <# Drop a GptTmpl.inf into the GPO and register the Security CSE + bump. #>
    param([Parameter(Mandatory)]$Gpo, [Parameter(Mandatory)][string]$Inf)
    $path = "\\$domainFqdn\SYSVOL\$domainFqdn\Policies\{$($Gpo.Id)}\Machine\Microsoft\Windows NT\SecEdit\GptTmpl.inf"
    $utf16 = New-Object System.Text.UnicodeEncoding($false, $true)   # UTF-16LE + BOM, as secpol expects
    if (Write-LabSysvolFile -Path $path -Content $Inf -Encoding $utf16) {
        Add-LabGpoExtension -GpoId $Gpo.Id -Side Machine -ExtString $CSE_SECURITY
        Step-LabGpoVersion -GpoId $Gpo.Id -Side Machine
        Write-LabStep "Security template written for '$($Gpo.DisplayName)'" -Level Done
    }
    else {
        Write-LabStep "Security template for '$($Gpo.DisplayName)' unchanged" -Level Skip
    }
}

function Get-LabGroupSid {
    param([Parameter(Mandatory)][string]$Name)
    (Get-ADGroup -Identity $Name).SID.Value
}

# =====================================================================
# -FromBackup: reimport everything and stop
# =====================================================================
$gpoNames = @('CORP-Audit-Baseline', 'CORP-User-Wallpaper', 'CORP-Drive-Maps',
    'CORP-USB-Storage-Block', 'CORP-RDP-Restriction')

if ($FromBackup) {
    if (-not (Test-Path (Join-Path $backupRoot 'manifest.xml'))) {
        throw "No GPO backups in $backupRoot. Run .\04-gpos.ps1 once (no switch) to create them."
    }
    foreach ($name in $gpoNames) {
        Write-LabStep "Importing '$name' from backup"
        Import-GPO -BackupGpoName $name -TargetName $name -Path $backupRoot -CreateIfNeeded | Out-Null
    }
    Write-LabStep 'Re-linking imported GPOs'
    Set-LabGpoLink -Name 'CORP-Audit-Baseline'    -Target $domainDN        -Enforced Yes
    Set-LabGpoLink -Name 'CORP-User-Wallpaper'    -Target $usersRootDN
    Set-LabGpoLink -Name 'CORP-Drive-Maps'        -Target $usersRootDN
    Set-LabGpoLink -Name 'CORP-USB-Storage-Block' -Target $usersRootDN
    Set-LabGpoLink -Name 'CORP-RDP-Restriction'   -Target $computersRootDN
    Write-LabStep 'Import complete. Note: password policy / PSO are AD objects, not GPO backups - re-run without -FromBackup to reapply those.' -Level Warn
    return
}

# =====================================================================
# 1. Password + lockout policy  (Default Domain Policy)
# =====================================================================
Write-LabStep 'Applying domain password + lockout policy'
$p = $g.Password
Set-ADDefaultDomainPasswordPolicy -Identity $domainFqdn `
    -MinPasswordLength $p.MinLength `
    -MaxPasswordAge ([TimeSpan]::FromDays($p.MaxAgeDays)) `
    -MinPasswordAge ([TimeSpan]::FromDays($p.MinAgeDays)) `
    -PasswordHistoryCount $p.HistoryCount `
    -ComplexityEnabled $p.ComplexityEnabled `
    -ReversibleEncryptionEnabled $p.ReversibleEncryption `
    -LockoutThreshold $p.LockoutThreshold `
    -LockoutDuration ([TimeSpan]::FromMinutes($p.LockoutDurationMin)) `
    -LockoutObservationWindow ([TimeSpan]::FromMinutes($p.LockoutWindowMin))
Write-LabStep "Domain policy: $($p.MinLength)-char min, lockout $($p.LockoutThreshold) tries / $($p.LockoutDurationMin) min" -Level Done

# =====================================================================
# 2. Fine-grained password policy for admin accounts (PSO)
# =====================================================================
Write-LabStep 'Applying stricter fine-grained password policy for admins'
$ap = $g.AdminPassword
$pso = Get-ADFineGrainedPasswordPolicy -Filter "Name -eq '$($ap.Name)'" -ErrorAction SilentlyContinue
$psoParams = @{
    MinPasswordLength        = $ap.MinLength
    MaxPasswordAge           = ([TimeSpan]::FromDays($ap.MaxAgeDays))
    PasswordHistoryCount     = $ap.HistoryCount
    ComplexityEnabled        = $true
    LockoutThreshold         = $ap.LockoutThreshold
    LockoutDuration          = ([TimeSpan]::FromMinutes($ap.LockoutDurationMin))
    LockoutObservationWindow = ([TimeSpan]::FromMinutes($ap.LockoutWindowMin))
    Precedence               = $ap.Precedence
}
if ($pso) {
    Set-ADFineGrainedPasswordPolicy -Identity $ap.Name @psoParams
    Write-LabStep "PSO '$($ap.Name)' updated" -Level Skip
}
else {
    New-ADFineGrainedPasswordPolicy -Name $ap.Name -DisplayName $ap.Name @psoParams
    Write-LabStep "PSO '$($ap.Name)' created ($($ap.MinLength)-char min, 30-day max)" -Level Done
}
# Subjects: the Tier1 group + the built-in Domain Admins group
foreach ($subject in @($ap.AppliesToGroup, 'Domain Admins')) {
    $current = (Get-ADFineGrainedPasswordPolicy -Identity $ap.Name -Properties AppliesTo).AppliesTo
    $subjectDN = (Get-ADGroup -Identity $subject).DistinguishedName
    if ($current -notcontains $subjectDN) {
        Add-ADFineGrainedPasswordPolicySubject -Identity $ap.Name -Subjects $subject
        Write-LabStep "PSO applied to $subject" -Level Done
    }
    else {
        Write-LabStep "PSO already applies to $subject" -Level Skip
    }
}

# =====================================================================
# 3. CORP-Audit-Baseline  -  logon + object access auditing
#    Linked at the domain root and Enforced so no OU can switch auditing
#    back off with block inheritance.
# =====================================================================
$auditGpo = Get-LabGpo -Name 'CORP-Audit-Baseline'
$auditInf = @'
[Unicode]
Unicode=yes
[Version]
signature="$CHICAGO$"
Revision=1
[Event Audit]
AuditSystemEvents = 3
AuditLogonEvents = 3
AuditObjectAccess = 3
AuditPrivilegeUse = 0
AuditPolicyChange = 1
AuditAccountManage = 3
AuditProcessTracking = 0
AuditDSAccess = 3
AuditAccountLogon = 3
[Registry Values]
MACHINE\System\CurrentControlSet\Control\Lsa\SCENoApplyLegacyAuditPolicy=4,0
'@
# SCENoApplyLegacyAuditPolicy=0 lets these legacy categories take effect even
# though Advanced Audit Policy exists on modern Windows.
Set-LabGpoSecurityTemplate -Gpo $auditGpo -Inf $auditInf
Set-LabGpoLink -Name 'CORP-Audit-Baseline' -Target $domainDN -Enforced Yes

# =====================================================================
# 4. CORP-User-Wallpaper  -  locked corporate wallpaper (Corp/Users)
# =====================================================================
$wallGpo = Get-LabGpo -Name 'CORP-User-Wallpaper'

# Generate a placeholder wallpaper into NETLOGON if one isn't there yet.
$netlogonWall = "\\$domainFqdn\NETLOGON\corp-wallpaper.jpg"
if (-not (Test-Path $netlogonWall)) {
    try {
        Add-Type -AssemblyName System.Drawing
        $bmp = New-Object System.Drawing.Bitmap 1920, 1080
        $gfx = [System.Drawing.Graphics]::FromImage($bmp)
        $gfx.Clear([System.Drawing.Color]::FromArgb(22, 63, 59))
        $font = New-Object System.Drawing.Font('Segoe UI', 64, [System.Drawing.FontStyle]::Bold)
        $sub  = New-Object System.Drawing.Font('Consolas', 28)
        $brush = [System.Drawing.Brushes]::White
        $gfx.DrawString('corp.lab', $font, $brush, 120, 420)
        $gfx.DrawString('Authorized use only - activity is audited', $sub, $brush, 128, 560)
        $bmp.Save($netlogonWall, [System.Drawing.Imaging.ImageFormat]::Jpeg)
        $gfx.Dispose(); $bmp.Dispose()
        Write-LabStep "Generated placeholder wallpaper at $netlogonWall" -Level Done
    }
    catch {
        Write-LabStep "Could not auto-generate wallpaper ($($_.Exception.Message)). Drop any .jpg at $netlogonWall by hand." -Level Warn
    }
}

Set-GPRegistryValue -Name 'CORP-User-Wallpaper' `
    -Key 'HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System' `
    -ValueName 'Wallpaper' -Type String -Value $g.WallpaperUNC | Out-Null
Set-GPRegistryValue -Name 'CORP-User-Wallpaper' `
    -Key 'HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\System' `
    -ValueName 'WallpaperStyle' -Type String -Value $g.WallpaperStyle | Out-Null
Set-GPRegistryValue -Name 'CORP-User-Wallpaper' `
    -Key 'HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\ActiveDesktop' `
    -ValueName 'NoChangingWallPaper' -Type DWord -Value 1 | Out-Null
Write-LabStep "Wallpaper policy set -> $($g.WallpaperUNC)" -Level Done
Set-LabGpoLink -Name 'CORP-User-Wallpaper' -Target $usersRootDN

# =====================================================================
# 5. CORP-Drive-Maps  -  GPP drive maps with ITEM-LEVEL TARGETING
#    G:  \\FS01\Company$   -> everyone (no filter)
#    S:  \\FS01\<Dept>$    -> one item per dept, filtered to CORP\SG-<Dept>
# =====================================================================
$driveGpo = Get-LabGpo -Name 'CORP-Drive-Maps'

$common = $g.CommonDrive
$driveItems = @()
$driveItems += @"
	<Drive clsid="{935D1B74-9CB8-4e3c-9914-7DD559B7A417}" name="$($common.Letter):" status="$($common.Letter):" image="2" changed="2026-01-01 00:00:00" uid="$($DRIVE_UID.Common)" bypassErrors="1">
		<Properties action="U" thisDrive="NOCHANGE" allDrives="NOCHANGE" userName="" path="\\$($g.FileServerHost)\$($common.Share)" label="$($common.Label)" persistent="1" useLetter="1" letter="$($common.Letter)"/>
	</Drive>
"@

foreach ($dept in $cfg.OU.Departments) {
    $sid = Get-LabGroupSid -Name "SG-$dept"
    $driveItems += @"
	<Drive clsid="{935D1B74-9CB8-4e3c-9914-7DD559B7A417}" name="$($g.DeptDriveLetter):" status="$($g.DeptDriveLetter):" image="2" changed="2026-01-01 00:00:00" uid="$($DRIVE_UID[$dept])" bypassErrors="1" desc="$dept department share">
		<Properties action="U" thisDrive="NOCHANGE" allDrives="NOCHANGE" userName="" path="\\$($g.FileServerHost)\$dept`$" label="$dept ($($g.DeptDriveLetter):)" persistent="1" useLetter="1" letter="$($g.DeptDriveLetter)"/>
		<Filters>
			<FilterGroup bool="AND" not="0" name="$($cfg.NetBIOSName)\SG-$dept" sid="$sid" userContext="1" primaryGroup="0" localGroup="0"/>
		</Filters>
	</Drive>
"@
}

$drivesXml = @"
<?xml version="1.0" encoding="utf-8"?>
<Drives clsid="{8FDDCC1A-0C3C-43cd-A6B4-71A6DF20DA8C}">
$($driveItems -join "`r`n")
</Drives>
"@

$drivesPath = "\\$domainFqdn\SYSVOL\$domainFqdn\Policies\{$($driveGpo.Id)}\User\Preferences\Drives\Drives.xml"
$utf8 = New-Object System.Text.UTF8Encoding($false)
if (Write-LabSysvolFile -Path $drivesPath -Content $drivesXml -Encoding $utf8) {
    Add-LabGpoExtension -GpoId $driveGpo.Id -Side User -ExtString $CSE_DRIVEMAPS
    Step-LabGpoVersion  -GpoId $driveGpo.Id -Side User
    Write-LabStep 'Drives.xml written (1 common + 5 dept-filtered items)' -Level Done
}
else {
    Write-LabStep 'Drives.xml unchanged' -Level Skip
}
Set-LabGpoLink -Name 'CORP-Drive-Maps' -Target $usersRootDN

# =====================================================================
# 6. CORP-USB-Storage-Block  -  block USB mass storage for everyone but IT
#    Security filtering: Apply = SG-AllStaff, plus DENY-Apply for SG-IT.
# =====================================================================
$usbGpo = Get-LabGpo -Name 'CORP-USB-Storage-Block'
# User-side "All Removable Storage classes: Deny all access"
Set-GPRegistryValue -Name 'CORP-USB-Storage-Block' `
    -Key 'HKCU\Software\Policies\Microsoft\Windows\RemovableStorageDevices' `
    -ValueName 'Deny_All' -Type DWord -Value 1 | Out-Null
Write-LabStep 'USB storage: Deny_All set (user side)' -Level Done
Set-LabGpoApplyGroups -Name 'CORP-USB-Storage-Block' -Groups @('SG-AllStaff')
Add-LabGpoDenyApply  -GpoId $usbGpo.Id -GroupName $g.UsbBlockExemptGroup
Set-LabGpoLink -Name 'CORP-USB-Storage-Block' -Target $usersRootDN

# =====================================================================
# 7. CORP-RDP-Restriction  -  who may log on over RDP (Corp/Computers)
#    Restricts the SeRemoteInteractiveLogonRight user right to
#    BUILTIN\Administrators + SG-Tier1-Admins, denies it to Guests, and
#    forces Network Level Authentication.
# =====================================================================
$rdpGpo = Get-LabGpo -Name 'CORP-RDP-Restriction'
$tier1Sid = Get-LabGroupSid -Name $g.RdpAllowedGroup
$rdpInf = @"
[Unicode]
Unicode=yes
[Version]
signature="`$CHICAGO`$"
Revision=1
[Privilege Rights]
SeRemoteInteractiveLogonRight = *S-1-5-32-544,*$tier1Sid
SeDenyRemoteInteractiveLogonRight = *S-1-5-32-546
"@
Set-LabGpoSecurityTemplate -Gpo $rdpGpo -Inf $rdpInf
# Require Network Level Authentication for any RDP session
Set-GPRegistryValue -Name 'CORP-RDP-Restriction' `
    -Key 'HKLM\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services' `
    -ValueName 'UserAuthentication' -Type DWord -Value 1 | Out-Null
Write-LabStep 'RDP: user right restricted to Administrators + SG-Tier1-Admins, NLA required' -Level Done
Set-LabGpoLink -Name 'CORP-RDP-Restriction' -Target $computersRootDN

# =====================================================================
# Back up every scripted GPO into .\gpos\  (so the repo carries the
# definitions and -FromBackup can rebuild them without the editor)
# =====================================================================
if (-not $SkipBackup) {
    Write-LabStep 'Backing up GPOs into .\gpos\'
    Get-ChildItem -Path $backupRoot -Directory -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force
    Remove-Item (Join-Path $backupRoot 'manifest.xml') -ErrorAction SilentlyContinue
    foreach ($name in $gpoNames) {
        Backup-GPO -Name $name -Path $backupRoot -Comment "04-gpos.ps1 $(Get-Date -Format s)" | Out-Null
        Write-LabStep "Backed up '$name'" -Level Done
    }
}

# =====================================================================
# Refresh policy on the DC and report
# =====================================================================
Write-LabStep 'Running gpupdate on the DC'
try { Invoke-GPUpdate -Force -ErrorAction Stop } catch { gpupdate /force | Out-Null }

Write-LabStep 'Phase 2 complete' -Level Done
Write-Host ''
Write-LabStep 'GPOs and links:'
Get-GPO -All | Where-Object { $_.DisplayName -like 'CORP-*' } |
    Sort-Object DisplayName |
    Format-Table DisplayName, GpoStatus, @{ N = 'Version'; E = { $_.Computer.DSVersion + $_.User.DSVersion } } -AutoSize

Write-Host ''
Write-LabStep 'Next steps:'
Write-LabStep '  - Join CLIENT01/CLIENT02, move them into Corp/Computers/<Dept>, run gpupdate /force, log in as a seeded user.'
Write-LabStep '  - Verify: gpresult /r  (user)  and  gpresult /r /scope computer  (elevated).'
Write-LabStep '  - Read GPO-PRECEDENCE.md for which GPO wins where.'
Write-LabStep '  - The S:/G: drive maps and department shares only work once Phase 3 (05-fileserver.ps1) creates the shares on FS01.'
