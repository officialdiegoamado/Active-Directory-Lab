#requires -Version 5.1
<#
    Shared helpers used by every numbered script in this repo.
    Keeps config-loading, logging, and idempotency checks consistent
    so each phase script can stay focused on its own logic.
#>

function Get-LabConfig {
    [CmdletBinding()]
    param(
        [string]$Path = (Join-Path $PSScriptRoot 'Lab.Config.psd1')
    )
    Import-PowerShellDataFile -Path $Path
}

function Get-LabDomainDN {
    param([Parameter(Mandatory)][string]$DomainName)
    'DC=' + ($DomainName -split '\.' -join ',DC=')
}

function Write-LabStep {
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('Info', 'Warn', 'Skip', 'Done')][string]$Level = 'Info'
    )
    $color = switch ($Level) {
        'Info' { 'Cyan' }
        'Warn' { 'Yellow' }
        'Skip' { 'DarkGray' }
        'Done' { 'Green' }
    }
    $tag = switch ($Level) {
        'Info' { '..' }
        'Warn' { '!!' }
        'Skip' { '--' }
        'Done' { 'OK' }
    }
    Write-Host "[$tag] $Message" -ForegroundColor $color
}

function Assert-RunningAsAdministrator {
    $principal = New-Object Security.Principal.WindowsPrincipal(
        [Security.Principal.WindowsIdentity]::GetCurrent()
    )
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'This script must be run from an elevated (Run as Administrator) PowerShell session.'
    }
}

function Test-LabDomainControllerPromoted {
    # NTDS only exists/runs once this box has actually been promoted to a DC.
    $svc = Get-Service -Name NTDS -ErrorAction SilentlyContinue
    return [bool]$svc
}

function New-LabOU {
    <#
        Idempotent OU creation: creates the OU only if it doesn't already
        exist, otherwise leaves it (and anything already inside it) alone.
    #>
    param(
        [Parameter(Mandatory)][string]$Name,
        [Parameter(Mandatory)][string]$Path,
        [switch]$Protect = $true
    )
    $existing = Get-ADOrganizationalUnit -Filter "Name -eq '$Name'" -SearchBase $Path -SearchScope OneLevel -ErrorAction SilentlyContinue
    if ($existing) {
        Write-LabStep "OU '$Name' already exists under $Path" -Level Skip
        return $existing
    }
    Write-LabStep "Creating OU '$Name' under $Path"
    New-ADOrganizationalUnit -Name $Name -Path $Path -ProtectedFromAccidentalDeletion:$Protect
    return Get-ADOrganizationalUnit -Filter "Name -eq '$Name'" -SearchBase $Path -SearchScope OneLevel
}

function ConvertTo-LabSecurePassword {
    param([Parameter(Mandatory)][string]$PlainText)
    ConvertTo-SecureString -String $PlainText -AsPlainText -Force
}

Export-ModuleMember -Function *
