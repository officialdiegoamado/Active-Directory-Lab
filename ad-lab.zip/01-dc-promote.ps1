<#
    01-dc-promote.ps1

    Turns a freshly installed, workgroup-joined Windows Server 2022 VM into
    DC01, the first (and only) domain controller of a new forest, corp.lab.

    IDEMPOTENT / RE-RUNNABLE:
    This script has to survive two reboots (computer rename, then AD DS
    promotion), so every step checks current state before acting and skips
    if it's already done. Just re-run the script after each reboot and it
    will pick up where it left off.

    Run order:
      1. Set static IP on the lab NIC
      2. Rename the computer to DCName (reboot if changed)
      3. Install AD DS + DNS + DHCP features
      4. Promote to a new forest (auto-reboots)
      5. Post-promotion: DNS forwarders, reverse lookup zone,
         DHCP scope + authorization
#>

#requires -RunAsAdministrator
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Import-Module (Join-Path $PSScriptRoot 'Lab.Common.psm1') -Force
Assert-RunningAsAdministrator
$cfg = Get-LabConfig

# -----------------------------------------------------------------
# Step 1 - Static IP
# -----------------------------------------------------------------
Write-LabStep 'Checking network configuration'

$adapter =
    if ($cfg.Network.InterfaceAlias) {
        Get-NetAdapter -Name $cfg.Network.InterfaceAlias
    }
    else {
        Get-NetAdapter -Physical | Where-Object Status -eq 'Up' | Select-Object -First 1
    }

if (-not $adapter) {
    throw 'No active network adapter found. Set Network.InterfaceAlias in Lab.Config.psd1.'
}

$desiredIP = $cfg.Network.DCIPAddress
$currentIP = (Get-NetIPAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object IPAddress -ne '127.0.0.1' | Select-Object -First 1).IPAddress

if ($currentIP -eq $desiredIP) {
    Write-LabStep "Static IP already set to $desiredIP" -Level Skip
}
else {
    Write-LabStep "Setting static IP $desiredIP/$($cfg.Network.PrefixLength) on $($adapter.Name)"
    Get-NetIPAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue |
        Remove-NetIPAddress -Confirm:$false -ErrorAction SilentlyContinue
    Remove-NetRoute -InterfaceIndex $adapter.ifIndex -DestinationPrefix '0.0.0.0/0' -Confirm:$false -ErrorAction SilentlyContinue

    New-NetIPAddress -InterfaceIndex $adapter.ifIndex -IPAddress $desiredIP `
        -PrefixLength $cfg.Network.PrefixLength -DefaultGateway $cfg.Network.Gateway | Out-Null

    # A DC should point at itself for DNS once it's authoritative for the zone.
    Set-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -ServerAddresses $desiredIP
    Write-LabStep "Static IP configured" -Level Done
}

# -----------------------------------------------------------------
# Step 2 - Computer rename (must happen before promotion)
# -----------------------------------------------------------------
if ($env:COMPUTERNAME -eq $cfg.DCName) {
    Write-LabStep "Computer name already '$($cfg.DCName)'" -Level Skip
}
else {
    Write-LabStep "Renaming computer to '$($cfg.DCName)' - a reboot is required"
    Rename-Computer -NewName $cfg.DCName -Force
    Write-LabStep 'Restarting now. RE-RUN THIS SCRIPT after the reboot to continue.' -Level Warn
    Restart-Computer -Force
    return
}

# -----------------------------------------------------------------
# Step 3 - Install roles/features
# -----------------------------------------------------------------
$featuresNeeded = 'AD-Domain-Services', 'DNS', 'DHCP'
$missing = $featuresNeeded | Where-Object { (Get-WindowsFeature -Name $_).InstallState -ne 'Installed' }

if (-not $missing) {
    Write-LabStep 'AD DS, DNS, and DHCP features already installed' -Level Skip
}
else {
    Write-LabStep "Installing features: $($missing -join ', ')"
    Install-WindowsFeature -Name $featuresNeeded -IncludeManagementTools | Out-Null
    Write-LabStep 'Features installed' -Level Done
}

# -----------------------------------------------------------------
# Step 4 - Promote to a new forest (auto-reboots on completion)
# -----------------------------------------------------------------
if (Test-LabDomainControllerPromoted) {
    Write-LabStep "$($cfg.DCName) is already a domain controller for $($cfg.DomainName)" -Level Skip
}
else {
    Write-LabStep "Promoting to a new forest: $($cfg.DomainName)"
    $dsrmPassword = Read-Host -AsSecureString -Prompt 'Set the Directory Services Restore Mode (DSRM) password'

    Install-ADDSForest `
        -DomainName $cfg.DomainName `
        -DomainNetbiosName $cfg.NetBIOSName `
        -InstallDns:$true `
        -SafeModeAdministratorPassword $dsrmPassword `
        -Force `
        -NoRebootOnCompletion:$false

    # Install-ADDSForest reboots automatically; execution stops here.
    return
}

# -----------------------------------------------------------------
# Step 5 - Post-promotion: DNS forwarders, reverse zone, DHCP
# -----------------------------------------------------------------
Import-Module DnsServer
Import-Module DhcpServer

Write-LabStep 'Checking DNS forwarders'
$currentForwarders = (Get-DnsServerForwarder -ErrorAction SilentlyContinue).IPAddress.IPAddressToString
$wantForwarders = $cfg.Network.DNSForwarders
if ($currentForwarders -and (Compare-Object $currentForwarders $wantForwarders -SyncWindow 0 | Measure-Object).Count -eq 0) {
    Write-LabStep "DNS forwarders already set to $($wantForwarders -join ', ')" -Level Skip
}
else {
    Write-LabStep "Setting DNS forwarders to $($wantForwarders -join ', ')"
    Set-DnsServerForwarder -IPAddress $wantForwarders
    Write-LabStep 'DNS forwarders configured' -Level Done
}

Write-LabStep 'Checking reverse lookup zone'
$reverseNet = $cfg.Network.ReverseZoneNetworkID
$zoneName = ($reverseNet.Split('/')[0] -split '\.')[2, 1, 0] -join '.'
$zoneName = "$zoneName.in-addr.arpa"
if (Get-DnsServerZone -Name $zoneName -ErrorAction SilentlyContinue) {
    Write-LabStep "Reverse lookup zone $zoneName already exists" -Level Skip
}
else {
    Write-LabStep "Creating reverse lookup zone $zoneName"
    Add-DnsServerPrimaryZone -NetworkID $reverseNet -ReplicationScope 'Forest'
    Write-LabStep 'Reverse lookup zone created' -Level Done
}

Write-LabStep 'Checking DHCP scope'
$scope = Get-DhcpServerv4Scope -ScopeId $cfg.DHCP.ScopeID -ErrorAction SilentlyContinue
if ($scope) {
    Write-LabStep "DHCP scope $($cfg.DHCP.ScopeID) already exists" -Level Skip
}
else {
    Write-LabStep "Creating DHCP scope $($cfg.DHCP.ScopeName) ($($cfg.DHCP.StartRange)-$($cfg.DHCP.EndRange))"
    Add-DhcpServerv4Scope -Name $cfg.DHCP.ScopeName `
        -StartRange $cfg.DHCP.StartRange -EndRange $cfg.DHCP.EndRange `
        -SubnetMask $cfg.DHCP.SubnetMask -LeaseDuration ([TimeSpan]::Parse($cfg.DHCP.LeaseDuration)) -State Active

    Set-DhcpServerv4OptionValue -ScopeId $cfg.DHCP.ScopeID `
        -Router $cfg.DHCP.Router `
        -DnsServer $cfg.Network.DCIPAddress `
        -DnsDomain $cfg.DomainName
    Write-LabStep 'DHCP scope created' -Level Done
}

Write-LabStep 'Checking DHCP authorization in AD'
$authorized = Get-DhcpServerInDC | Where-Object DnsName -like "$($cfg.DCName)*"
if ($authorized) {
    Write-LabStep 'DHCP server already authorized in AD' -Level Skip
}
else {
    Write-LabStep 'Authorizing DHCP server in AD'
    Add-DhcpServerInDC -DnsName "$($cfg.DCName).$($cfg.DomainName)" -IPAddress $cfg.Network.DCIPAddress
    Restart-Service dhcpserver
    Write-LabStep 'DHCP server authorized' -Level Done
}

Write-LabStep "$($cfg.DCName) is fully promoted and configured for $($cfg.DomainName)" -Level Done
Write-LabStep 'Phase 1 next step: run 02-ou-structure.ps1'
